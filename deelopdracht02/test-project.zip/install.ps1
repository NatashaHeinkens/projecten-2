# Origineel van http://www.developer.com/net/virtualize-your-windows-development-environments-with-vagrant-packer-and-chocolatey-part-2.html
#Import-Module ServerManager
#$features = @(
#  "Web-WebServer",
#   "Web-Static-Content",
#   "Web-Http-Errors",
#   "Web-Http-Redirect",
#   "Web-Stat-Compression",
#   "Web-Filtering",
#   "Web-Asp-Net45",
#   "Web-Net-Ext45",
#   "Web-ISAPI-Ext",
#   "Web-ISAPI-Filter",
#   "Web-Mgmt-Console",
#   "Web-Mgmt-Tools",
#   "NET-Framework-45-ASPNET"
#)

# 
Import-Module ServerManager
$features = @(
   "Web-Server",
   "Web-WebServer",
   "Web-Common-Http",
   "Web-Static-Content",
   "Web-Default-Doc",
   "Web-Dir-Browsing",
   "Web-Http-Errors",
   "Web-Http-Redirect",
   "Web-Stat-Compression",
   "Web-Filtering",
   "Web-ASP",
   "Web-Asp-Net45",
   "Web-Net-Ext45",
   "Web-ISAPI-Ext",
   "Web-ISAPI-Filter",
   "Web-Mgmt-Console",
   "Web-Mgmt-Tools",
   "NET-Framework-45-ASPNET",
   "Web-App-Dev",
   "Web-Http-Logging",
   "Web-Log-Libraries"
)

#SQL Server en Webdeploy
Add-WindowsFeature $features -Verbose
iex ((new-object net.webclient).DownloadString('https://chocolatey.org/install.ps1'))
#choco install mysql
choco install mssqlserver2012express
choco install webdeploy

#SQL Server provisioning
Invoke-Sqlcmd -InputFile "C:\vagrant\sql_config.sql" -ServerInstance ".\SQLEXPRESS"