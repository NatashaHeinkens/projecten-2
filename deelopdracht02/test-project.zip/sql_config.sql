declare @login_name sysname
declare @db_name sysname
declare @password sysname

SET @login_name = 'VAGRANT'
SET @password ='PASSWORD1$'
SET @db_name = 'TESTDB'


declare @sql nvarchar(max)

exec sp_validname @login_name
exec sp_validname @db_name

-- Creating the login
--
set @sql = 'CREATE LOGIN ' + QUOTENAME(@login_name) + 
    ' WITH PASSWORD = ''' + REPLACE(@password, '''', '''''') + ''''
execute( @sql )
set @sql = 'ALTER LOGIN ' + QUOTENAME(@login_name)  
    + ' WITH CHECK_POLICY = ON'
execute( @sql )
set @sql = 'ALTER LOGIN ' + QUOTENAME(@login_name)  + 
    ' WITH CHECK_EXPIRATION = OFF'
execute( @sql )

-- Allows the user to connect to the server
set @sql = 'GRANT CONNECT SQL TO ' + QUOTENAME(@login_name)
execute( @sql )

-- Removes the ability to select from sys.databases
set @sql = 'DENY VIEW ANY DATABASE TO ' + QUOTENAME(@login_name)
execute( @sql )



-- Creating the database
--
set @sql = 'CREATE DATABASE ' + QUOTENAME(@db_name)
execute( @sql )

set @sql = 'ALTER DATABASE ' + QUOTENAME(@db_name) + 
    ' MODIFY FILE (NAME=''' + @db_name + 
    ''', MAXSIZE=200, SIZE=5, FILEGROWTH=5)' -- Set max data file size
execute( @sql )
set @sql = 'ALTER DATABASE ' + QUOTENAME(@db_name) + 
    ' MODIFY FILE (NAME=''' + @db_name + 
    '_log'', MAXSIZE=75, SIZE=2, FILEGROWTH=5)' -- set max log file size
execute( @sql )
set @sql = 'ALTER DATABASE ' + QUOTENAME(@db_name) + 
    ' SET TRUSTWORTHY OFF'
execute( @sql )
set @sql = 'ALTER DATABASE ' + QUOTENAME(@db_name) + 
    ' SET AUTO_CLOSE ON'
execute( @sql )
set @sql = 'ALTER DATABASE ' + QUOTENAME(@db_name) + 
    ' SET AUTO_SHRINK ON'
execute( @sql )
set @sql = 'ALTER DATABASE ' + QUOTENAME(@db_name) + 
    ' SET AUTO_UPDATE_STATISTICS ON'
execute( @sql )
set @sql = 'ALTER DATABASE ' + QUOTENAME(@db_name) + 
    ' SET AUTO_UPDATE_STATISTICS_ASYNC ON'
execute( @sql )

set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'CREATE USER ' + QUOTENAME(@login_name) + 
    ' FOR LOGIN ' + QUOTENAME(@login_name)
execute( @sql )

-- Create a default full-text catalog
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'CREATE FULLTEXT CATALOG [' + @db_name + '_fulltext]  AS DEFAULT'
execute( @sql )

-- Set the user to use the database created
set @sql = 'ALTER LOGIN ' + QUOTENAME(@login_name)  + 
    ' WITH DEFAULT_DATABASE = ' + QUOTENAME(@db_name)
execute( @sql )


-- Add the user and configure
--
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'exec sp_addrolemember ''db_ddladmin'', ''' + 
    REPLACE(@login_name, '''', '''''') + ''''
execute( @sql )
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'exec sp_addrolemember ''db_datareader'', ''' + 
    REPLACE(@login_name, '''', '''''') + ''''
execute( @sql )
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'exec sp_addrolemember ''db_datawriter'', ''' + 
    REPLACE(@login_name, '''', '''''') + ''''
execute( @sql )

-- ******************************
-- Additional privledges granted
-- ******************************

-- Gives user ability control the DBO schema
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'GRANT CONTROL ON SCHEMA::dbo TO ' + QUOTENAME(@login_name) 
    + ' WITH GRANT OPTION' 
execute( @sql )

-- Needed to execute showplan
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'GRANT SHOWPLAN TO ' + QUOTENAME(@login_name)
execute( @sql )

-- Needed to manipulate application roles
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'GRANT ALTER ANY APPLICATION ROLE TO ' + QUOTENAME(@login_name)
execute( @sql )

-- Needed to manipulate roles
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'GRANT ALTER ANY ROLE TO ' + QUOTENAME(@login_name)
execute( @sql )

-- Needed to view definitions of objects
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'GRANT VIEW DEFINITION TO ' + QUOTENAME(@login_name)
execute( @sql )

-- Needed to create schemas
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'GRANT CREATE SCHEMA TO ' + QUOTENAME(@login_name)
execute( @sql )

-- Needed for database-level DMVs
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'GRANT VIEW DATABASE STATE TO ' + QUOTENAME(@login_name) 
execute( @sql )

-- ******************************
-- Additional privledges denied
-- ******************************

-- Can be used to access the file system using SQL Server 
-- credentials.  (Both CREATE and ALTER.)
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'DENY ALTER ANY ASSEMBLY TO ' + QUOTENAME(@login_name) 
execute( @sql )

-- Can be used to access the file system using the SQL Server
-- credentials.  (Both CREATE and ALTER)
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'DENY ALTER ANY ASYMMETRIC KEY TO ' + QUOTENAME(@login_name)
execute( @sql )

-- Can be used to access the file system using the SQL Server
-- credentials.  (Both CREATE and ALTER)
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'DENY ALTER ANY CERTIFICATE TO ' + QUOTENAME(@login_name) 
execute( @sql )

-- Partition, filegroups
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'DENY ALTER ANY DATASPACE TO ' + QUOTENAME(@login_name) 
execute( @sql )

-- Database DDL triggers
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'DENY ALTER ANY DATABASE DDL TRIGGER TO ' + QUOTENAME(@login_name) 
execute( @sql )

 -- Creates files for catalog
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'DENY CREATE FULLTEXT CATALOG TO ' + QUOTENAME(@login_name)
execute( @sql )

 -- Can be used to rebuild catalogs and move their locations
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'DENY ALTER ANY FULLTEXT CATALOG TO ' + QUOTENAME(@login_name)
execute( @sql )

-- No need to checkpoint
set @sql = 'USE ' + QUOTENAME(@db_name) + char(10) + 
    'DENY CHECKPOINT TO ' + QUOTENAME(@login_name) 
execute( @sql )
GO

